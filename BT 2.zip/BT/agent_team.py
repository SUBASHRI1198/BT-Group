import os
import warnings
from typing import Awaitable, Callable, List, Optional, Union

from autogen_agentchat.agents import CodeExecutorAgent, UserProxyAgent
from autogen_agentchat.base import ChatAgent
from autogen_agentchat.teams import MagenticOneGroupChat
from autogen_core import CancellationToken
from autogen_core.models import ChatCompletionClient
from autogen_ext.agents.file_surfer import FileSurfer
from autogen_ext.agents.magentic_one import MagenticOneCoderAgent
from autogen_ext.agents.web_surfer import MultimodalWebSurfer
from autogen_ext.code_executors.local import LocalCommandLineCodeExecutor
from autogen_ext.models.openai._openai_client import BaseOpenAIChatCompletionClient

from addon_agents import (
     CSVGenerationAgent,ExcelCreationAgent
)
from utilities import load_tools_1

SyncInputFunc = Callable[[str], str]
AsyncInputFunc = Callable[[str, Optional[CancellationToken]], Awaitable[str]]


class MagenticOne(MagenticOneGroupChat):
    """
    References:
        .. code-block:: bibtex

            @article{fourney2024magentic,
                title={Magentic-one: A generalist multi-agent system for solving complex tasks},
                author={Fourney, Adam and Bansal, Gagan and Mozannar, Hussein and Tan, Cheng and Salinas, Eduardo and Niedtner, Friederike and Proebsting, Grace and Bassman, Griffin and Gerrits, Jack and Alber, Jacob and others},
                journal={arXiv preprint arXiv:2411.04468},
                year={2024},
                url={https://arxiv.org/abs/2411.04468}
            }
    """

    def __init__(
        self,
        client: ChatCompletionClient,
        hill_mode: bool = False,
        input_func: Optional[Callable[[str], str]] = None,
        tools: List[dict] = [],  # Specify tools as a list of dictionaries
        agent_list: List = [],
        conv_id: str = ""
    ):  
        # Provide a default input_func if None is passed
        if input_func is None or not callable(input_func):
            def default_input_func(prompt: str) -> str:
                print(prompt)
                return input("Enter your response (yes/no): ").strip()
            input_func = default_input_func
        self.client = client
        self.tools = tools if isinstance(tools, list) else []  # Ensure tools is a list
        print(f"Initialized MagenticOne with tools: {self.tools}")  # Debug: Log tools initialization
        self._validate_client_capabilities(client)
        work_path = os.path.join(os.getcwd(), "magentic_logs")
        screenshot_path = os.path.join(work_path, "screenshots")
        execution_path = os.path.join(work_path, "code")
        os.makedirs(screenshot_path, exist_ok=True)
        os.makedirs(execution_path, exist_ok=True)

        # Initialize toolist to avoid UnboundLocalError
        toolist = []
        for i in tools:
            if 'agentname' in i and 'Tools' in i and i['Tools']:
                toolist = i['Tools'][0]
        print(toolist)
        agents: List[ChatAgent] = []
        if hill_mode:
            # Add UserProxyAgent for Human-in-the-Loop interaction
            user_proxy = UserProxyAgent("User", input_func=input_func)
            agents.append(user_proxy)
        for agent in agent_list:           
            if agent=="CSV Generation Agent":
                print(agent)
                toolist=load_tools_1(agent)
                tool = CSVGenerationAgent("CSVGenerationAgent", model_client=client,tools=toolist,workflow_id=conv_id)  # Updated name
                agents.append(tool)  
            elif agent == "WebSurfer Agent":
                print(agent)
                ws = MultimodalWebSurfer("WebSurfer", model_client=client, downloads_folder=screenshot_path)
                agents.append(ws)
            elif agent == "FileSurfer Agent":
                print(agent)
                fs = FileSurfer("FileSurfer", model_client=client)
                agents.append(fs) 
            elif agent=="Excel Creation Agent" :
                print(agent)
                toolist=load_tools_1(agent)
                tool = ExcelCreationAgent("ExcelCreationAgent", model_client=client,tools=toolist,workflow_id=conv_id)  # Updated name
                agents.append(tool)  
            elif agent == "Magentic-One Coder Agent":
                print(agent)
                coder = MagenticOneCoderAgent("Coder", model_client=client)
                agents.append(coder)
            elif agent == "Code Executor Agent":
                print(agent)
                executor = CodeExecutorAgent("Executor", code_executor=LocalCommandLineCodeExecutor(work_dir=execution_path))
                agents.append(executor)
            print("agents involved :", agents)
            super().__init__(agents, model_client=client)

    def _validate_client_capabilities(self, client: ChatCompletionClient) -> None:
        capabilities = client.model_info
        required_capabilities = ["vision", "function_calling", "json_output"]

        if not all(capabilities.get(cap) for cap in required_capabilities):
            warnings.warn(
                "Client capabilities for MagenticOne must include vision, " "function calling, and json output.",
                stacklevel=2,
            )

        if not isinstance(client, BaseOpenAIChatCompletionClient):
            warnings.warn(
                "MagenticOne performs best with OpenAI GPT-4o model either " "through OpenAI or Azure OpenAI.",
                stacklevel=2,
            )
