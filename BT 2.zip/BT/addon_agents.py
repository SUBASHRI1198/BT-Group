import json
import traceback
import time
from typing import List, Optional, Tuple,Sequence
import sqlite3
import mysql.connector as connection
import os
import csv
import pandas as pd
from fpdf import FPDF 
from autogen_core import CancellationToken, FunctionCall, default_subscription
from autogen_agentchat.agents import BaseChatAgent
from autogen_agentchat.base import Response
from autogen_agentchat.messages import (
    ChatMessage,
    MultiModalMessage,
    TextMessage,
)
from autogen_core.models import (
    AssistantMessage,
    ChatCompletionClient,
    LLMMessage,
    SystemMessage,
    UserMessage,
)
from autogen_core.tools import ToolSchema,ParametersSchema

from utilities import parse_documents

from typing import Any, Dict

############## Setup Tool Agent

def _load_tool(tooldef: Dict[str, Any]) -> ToolSchema:
    #print(tooldef)
    if tooldef["function"]["name"]=="parse_documents":
        return ToolSchema(
            name=tooldef["function"]["name"],
            description=tooldef["function"]["description"],
            parameters=ParametersSchema(
                type="object",
                properties=tooldef["function"]["parameters"]["properties"],
                required=tooldef["function"]["parameters"]["required"],
            ),
        )
    else:
        return ToolSchema(
            name=tooldef["function"]["name"],
            description=tooldef["function"]["description"],
            parameters=ParametersSchema(
                type="object",
                properties=json.loads(tooldef["function"]["parameters"])["properties"],
                required=json.loads(tooldef["function"]["parameters"])["required"],
            ),
        )

with open(os.path.join(os.getcwd(),"common_tools.json"),"r") as f:
    file_agent_def=json.loads(f.read())["parse_documents"]
###################CSV Generation Agent#############
class CSVGenerationAgent(BaseChatAgent):
    """An agent that uses tools to perform different activities"""

    def __init__(
        self,
        name: str,  # Updated default name
        model_client: ChatCompletionClient,
        description: str = "An agent that creates an CSV file from the information provided.",
        system_messages: List[SystemMessage] = [],
        tools: List[ToolSchema] = [],
        workflow_id: str = "",
    ) -> None:
        self._tools = []
        self._funcdefs = {}
        print("In CSV Creation Agent")
        for key in tools:
            self._tools.append(_load_tool(tools[key]["schema"]))
            self._funcdefs[key] = tools[key]["code"]
            print("Function Load:", key)


        description = description + "Below is the list of available tools:\n" + "\n".join(
            [elem['name'] + ": " + elem['description'] for elem in self._tools]
        )
        print("description :", description)
        super().__init__(name, description)
        self._model_client = model_client
        self.workflow_id = workflow_id
        self._system_messages = system_messages
        self._chat_history: List[LLMMessage] = []

    @property
    def produced_message_types(self) -> Sequence[type[ChatMessage]]:
        return (TextMessage,)

    async def on_messages(self, messages: Sequence[ChatMessage], cancellation_token: CancellationToken) -> Response:
        for chat_message in messages:
            if isinstance(chat_message, TextMessage | MultiModalMessage):
                self._chat_history.append(UserMessage(content=chat_message.content, source=chat_message.source))
            else:
                raise ValueError(f"Unexpected message in ToolAgent: {chat_message}")

        try:
            _, content = await self._generate_reply(cancellation_token=cancellation_token)
            self._chat_history.append(AssistantMessage(content=content, source=self.name))
            return Response(chat_message=TextMessage(content=content, source=self.name))

        except BaseException:
            content = f"CSV Creation Agent error:\n\n{traceback.format_exc()}"
            self._chat_history.append(AssistantMessage(content=content, source=self.name))
            return Response(chat_message=TextMessage(content=content, source=self.name))

    async def on_reset(self, cancellation_token: CancellationToken) -> None:
        self._chat_history.clear()

    async def _generate_reply(self, cancellation_token: CancellationToken) -> Tuple[bool, str]:
        history = self._chat_history[0:-1]
        last_message = self._chat_history[-1]
        assert isinstance(last_message, UserMessage)

        task_content = last_message.content  # the last message from the sender is the task

        task_message = UserMessage(
            source="user",
            content=task_content,
        )
        create_result = await self._model_client.create(
            messages=self._system_messages + history + [task_message], tools=self._tools, cancellation_token=cancellation_token
        )

        response = create_result.content
        print(response)
        if isinstance(response, str):
            return False, response

        elif isinstance(response, list) and all(isinstance(item, FunctionCall) for item in response):
            function_calls = response
            final_response = ""
            for function_call in function_calls:
                tool_name = function_call.name

                try:
                    # Debug: Log the raw arguments
                    print("Raw arguments from function_call:", function_call.arguments)

                    # Parse the arguments
                    arguments = json.loads(function_call.arguments)

                    # Debug: Log the parsed arguments
                    print("Parsed arguments:", arguments)

                except json.JSONDecodeError as e:
                    error_str = f"CSV Creation Agent encountered an error decoding JSON arguments: {e}"
                    return False, error_str

                exec(self._funcdefs[tool_name])
                function_to_call = locals().get(tool_name)
                if not function_to_call:
                    raise KeyError(f"Tool '{tool_name}' not found in available tools.")

                # Dynamically handle arguments based on the function signature
                from inspect import signature
                func_sig = signature(function_to_call)
                required_params = func_sig.parameters.keys()

                # Map argument keys to match required parameter names
                argument_mapping = {
                    "json_string": "json_string",
                    "conversation_id": "conversation_id"
                }

                # Extract workflow_id from the instance or task content
                mapped_arguments = {argument_mapping.get(k, k): v for k, v in arguments.items()}


                # Replace workflow_id in arguments if it exists
                if "workflow_id" in arguments:
                    arguments["workflow_id"] = mapped_arguments["workflow_id"]

                # Filter arguments to include only required parameters
                valid_arguments = {param: mapped_arguments.get(param) for param in required_params}
                print("valid_arguments", valid_arguments)
                # Check for missing parameters
                missing_params = [param for param, value in valid_arguments.items() if value is None]
                if missing_params:
                    error_str = f"Missing required parameters: {missing_params}"
                    print(error_str)
                    return False, error_str

                # Debug: Log the filtered arguments
                print("Filtered arguments:", valid_arguments)

                # Call the function with dynamically mapped arguments
                response_message = function_to_call(**valid_arguments)

                # Ensure response_message is a string
                if isinstance(response_message, tuple):
                    response_message = ''.join(str(item) for item in response_message)  # Convert tuple elements to strings
                elif not isinstance(response_message, str):
                    response_message = str(response_message)  # Convert non-string responses to string

                # Debug: Log the response message
                print("Response message:", response_message)

                # Update the source to "ExcelCreationAgent"
                self._chat_history.append(AssistantMessage(content=response_message, source="ExcelCreationAgent"))  # Updated name
                final_response = final_response + response_message
                print("final Response:", final_response)  # Concatenate safely
            return False, final_response

        final_response = "TERMINATE"
        return False, final_response

###################CSV Generation Agent#############
class ExcelCreationAgent(BaseChatAgent):
    """An agent that uses tools to perform different activities"""

    def __init__(
        self,
        name: str,  # Updated default name
        model_client: ChatCompletionClient,
        description: str = "An agent that creates an excel file from the information provided.",
        system_messages: List[SystemMessage] = [],
        tools: List[ToolSchema] = [],
        workflow_id: str = "",
    ) -> None:
        self._tools = []
        self._funcdefs = {}
        print("In excel Creation Agent")
        for key in tools:
            self._tools.append(_load_tool(tools[key]["schema"]))
            self._funcdefs[key] = tools[key]["code"]
            print("Function Load:", key)


        description = description + "Below is the list of available tools:\n" + "\n".join(
            [elem['name'] + ": " + elem['description'] for elem in self._tools]
        )
        print("description :", description)
        super().__init__(name, description)
        self._model_client = model_client
        self.workflow_id = workflow_id
        self._system_messages = system_messages
        self._chat_history: List[LLMMessage] = []

    @property
    def produced_message_types(self) -> Sequence[type[ChatMessage]]:
        return (TextMessage,)

    async def on_messages(self, messages: Sequence[ChatMessage], cancellation_token: CancellationToken) -> Response:
        for chat_message in messages:
            if isinstance(chat_message, TextMessage | MultiModalMessage):
                self._chat_history.append(UserMessage(content=chat_message.content, source=chat_message.source))
            else:
                raise ValueError(f"Unexpected message in ToolAgent: {chat_message}")

        try:
            _, content = await self._generate_reply(cancellation_token=cancellation_token)
            self._chat_history.append(AssistantMessage(content=content, source=self.name))
            return Response(chat_message=TextMessage(content=content, source=self.name))

        except BaseException:
            content = f"excel Creation Agent error:\n\n{traceback.format_exc()}"
            self._chat_history.append(AssistantMessage(content=content, source=self.name))
            return Response(chat_message=TextMessage(content=content, source=self.name))

    async def on_reset(self, cancellation_token: CancellationToken) -> None:
        self._chat_history.clear()

    async def _generate_reply(self, cancellation_token: CancellationToken) -> Tuple[bool, str]:
        history = self._chat_history[0:-1]
        last_message = self._chat_history[-1]
        assert isinstance(last_message, UserMessage)

        task_content = last_message.content  # the last message from the sender is the task

        task_message = UserMessage(
            source="user",
            content=task_content,
        )
        create_result = await self._model_client.create(
            messages=self._system_messages + history + [task_message], tools=self._tools, cancellation_token=cancellation_token
        )

        response = create_result.content
        print(response)
        if isinstance(response, str):
            return False, response

        elif isinstance(response, list) and all(isinstance(item, FunctionCall) for item in response):
            function_calls = response
            final_response = ""
            for function_call in function_calls:
                tool_name = function_call.name

                try:
                    # Debug: Log the raw arguments
                    print("Raw arguments from function_call:", function_call.arguments)

                    # Parse the arguments
                    arguments = json.loads(function_call.arguments)

                    # Debug: Log the parsed arguments
                    print("Parsed arguments:", arguments)

                except json.JSONDecodeError as e:
                    error_str = f"excel Creation Agent encountered an error decoding JSON arguments: {e}"
                    return False, error_str

                exec(self._funcdefs[tool_name])
                function_to_call = locals().get(tool_name)
                if not function_to_call:
                    raise KeyError(f"Tool '{tool_name}' not found in available tools.")

                # Dynamically handle arguments based on the function signature
                from inspect import signature
                func_sig = signature(function_to_call)
                required_params = func_sig.parameters.keys()

                # Map argument keys to match required parameter names
                argument_mapping = {
                    "json_string": "json_string",
                    "conversation_id": "conversation_id"
                }

                # Extract workflow_id from the instance or task content
                mapped_arguments = {argument_mapping.get(k, k): v for k, v in arguments.items()}


                # Replace workflow_id in arguments if it exists
                if "workflow_id" in arguments:
                    arguments["workflow_id"] = mapped_arguments["workflow_id"]

                # Filter arguments to include only required parameters
                valid_arguments = {param: mapped_arguments.get(param) for param in required_params}
                print("valid_arguments", valid_arguments)
                # Check for missing parameters
                missing_params = [param for param, value in valid_arguments.items() if value is None]
                if missing_params:
                    error_str = f"Missing required parameters: {missing_params}"
                    print(error_str)
                    return False, error_str

                # Debug: Log the filtered arguments
                print("Filtered arguments:", valid_arguments)

                # Call the function with dynamically mapped arguments
                response_message = function_to_call(**valid_arguments)

                # Ensure response_message is a string
                if isinstance(response_message, tuple):
                    response_message = ''.join(str(item) for item in response_message)  # Convert tuple elements to strings
                elif not isinstance(response_message, str):
                    response_message = str(response_message)  # Convert non-string responses to string

                # Debug: Log the response message
                print("Response message:", response_message)

                # Update the source to "ExcelCreationAgent"
                self._chat_history.append(AssistantMessage(content=response_message, source="ExcelCreationAgent"))  # Updated name
                final_response = final_response + response_message
                print("final Response:", final_response)  # Concatenate safely
            return False, final_response

        final_response = "TERMINATE"
        return False, final_response

